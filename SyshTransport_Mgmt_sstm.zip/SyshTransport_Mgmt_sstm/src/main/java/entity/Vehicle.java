package entity;

public class Vehicle {
    private int id;
    private String model;
    private double capacity;
    private String type;
    private String status;

    // Constructor
    public Vehicle(String model, double capacity, String type, String status) {
        this.model = model;
        this.capacity = capacity;
        this.type = type;
        this.status = status;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public double getCapacity() {
        return capacity;
    }

    public String getType() {
        return type;
    }

    public String getStatus() {
        return status;
    }
}