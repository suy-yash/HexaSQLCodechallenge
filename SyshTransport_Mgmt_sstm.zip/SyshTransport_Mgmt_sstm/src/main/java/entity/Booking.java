package entity;

public class Booking {
    private int id;
    private int vehicleId;
    private int passengerId; // Assuming a passenger ID
    private int tripId; // Assuming a trip ID
    private String date;
    private String time;

    // Constructor
    public Booking(int vehicleId, String date, String time) {
        this.vehicleId = vehicleId;
        this.passengerId = passengerId;
        this.tripId = tripId;
        this.date = date;
        this.time = time;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public int getPassengerId() {
        return passengerId;
    }

    public int getTripId() {
        return tripId;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }
}