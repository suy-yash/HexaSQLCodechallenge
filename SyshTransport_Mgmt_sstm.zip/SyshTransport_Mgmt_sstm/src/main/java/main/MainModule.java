
package main;

import dao.TransportManagementServiceImpl;
import entity.Vehicle;
import exception.BookingNotFoundException;
import exception.VehicleNotFoundException;
import java.util.Properties;
import util.DBPropertyUtil;
import java.util.*;

public class MainModule {
    public MainModule() {
    }

    public static void main(String[] var0) {
        Properties var1 = DBPropertyUtil.getConnectionProperties("src/main/resources/db.properties");
        TransportManagementServiceImpl var2 = new TransportManagementServiceImpl();
        Scanner var3 = new Scanner(System.in);

        while(true) {
            System.out.println("\nTransport Management System Menu:");
            System.out.println("1. Add Vehicle");
            System.out.println("2. Update Vehicle");
            System.out.println("3. Delete Vehicle");
            System.out.println("5. Cancel Trip");
            System.out.println("7. Cancel Booking");
            System.out.println("10. Get Bookings by Passenger");
            System.out.println("11. Get Bookings by Trip");
            System.out.println("12. Get Available Drivers");
            System.out.println("13. Exit");
            System.out.print("Enter choice: ");

            int var4;
            try {
                var4 = var3.nextInt();
                var3.nextLine();
            } catch (Exception var28) {
                System.out.println("Invalid input. Please enter a number.");
                var3.nextLine();
                continue;
            }

            try {
                switch (var4) {
                    case 1:
                        System.out.print("Enter model: ");
                        String var5 = var3.nextLine();
                        System.out.print("Enter capacity: ");
                        double var6 = var3.nextDouble();
                        var3.nextLine();
                        System.out.print("Enter type (e.g., Truck, Van, Bus): ");
                        String var8 = var3.nextLine();
                        System.out.print("Enter status (e.g., Available): ");
                        String var9 = var3.nextLine();
                        Vehicle var10 = new Vehicle(var5, var6, var8, var9);
                        System.out.println(var2.addVehicle(var10) ? "Vehicle added" : "Failed to add vehicle");
                        break;
                    case 2:
                        System.out.print("Enter vehicle ID: ");
                        int var11 = var3.nextInt();
                        var3.nextLine();
                        System.out.print("Enter new model: ");
                        String var12 = var3.nextLine();
                        System.out.print("Enter new capacity: ");
                        double var13 = var3.nextDouble();
                        var3.nextLine();
                        System.out.print("Enter new type: ");
                        String var15 = var3.nextLine();
                        System.out.print("Enter new status: ");
                        String var16 = var3.nextLine();
                        Vehicle var17 = new Vehicle(var12, var13, var15, var16);
                        var17.setId(var11);
                        System.out.println(var2.updateVehicle(var17) ? "Vehicle updated" : "Failed to update vehicle");
                        break;
                    case 3:
                        System.out.print("Enter vehicle ID: ");
                        int var18 = var3.nextInt();
                        if (var2.deleteVehicle(var18)) {
                            System.out.println("Vehicle deleted");
                        } else {
                            System.out.println("Failed to delete vehicle");
                        }
                        break;
                    case 4:
                    case 6:
                    case 8:
                    case 9:
                    default:
                        System.out.println("Invalid choice");
                        break;
                    case 5:
                        System.out.print("Enter trip ID: ");
                        int var19 = var3.nextInt();
                        System.out.println(var2.cancelTrip(var19) ? "Trip cancelled" : "Failed to cancel trip");
                        break;
                    case 7:
                        System.out.print("Enter booking ID: ");
                        int var20 = var3.nextInt();
                        if (var2.cancelBooking(var20)) {
                            System.out.println("Booking cancelled");
                        } else {
                            System.out.println("Failed to cancel booking");
                        }
                        break;
                    case 10:
                        System.out.print("Enter passenger ID: ");
                        int var21 = var3.nextInt();
                        List var22 = var2.getBookingsByPassenger(var21);
                        System.out.println(var22.isEmpty() ? "No bookings found" : var22);
                        break;
                    case 11:
                        System.out.print("Enter trip ID: ");
                        int var23 = var3.nextInt();
                        List var24 = var2.getBookingsByTrip(var23);
                        System.out.println(var24.isEmpty() ? "No bookings found" : var24);
                        break;
                    case 12:
                        System.out.println("Available Drivers:");
                        List var25 = var2.getAvailableDrivers();
                        System.out.println(var25.isEmpty() ? "No available drivers" : var25);
                        break;
                    case 13:
                        System.out.println("Exiting...");
                        var3.close();
                        System.exit(0);
                }
            } catch (BookingNotFoundException | VehicleNotFoundException var26) {
                System.out.println("Error: " + ((Exception)var26).getMessage());
            } catch (Exception var27) {
                System.out.println("An unexpected error occurred: " + var27.getMessage());
            }
        }
    }
}


