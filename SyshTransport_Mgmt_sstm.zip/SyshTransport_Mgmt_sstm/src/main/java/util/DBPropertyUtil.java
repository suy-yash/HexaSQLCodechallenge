package util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class DBPropertyUtil {
    public DBPropertyUtil() {
    }

    public static Properties getConnectionProperties(String var0) {
        Properties var1 = new Properties();

        try {
            FileInputStream var2 = new FileInputStream(var0);

            try {
                var1.load(var2);
            } catch (Throwable var6) {
                try {
                    var2.close();
                } catch (Throwable var5) {
                    var6.addSuppressed(var5);
                }

                throw var6;
            }

            var2.close();
        } catch (IOException var7) {
            System.err.println("Error reading properties file: " + var7.getMessage());
        }

        return var1;
    }
}
