package util;
import java.sql.*;
import java.util.Properties;

public class DBConnUtil1 {
    public DBConnUtil1() {
    }

    public static Connection getConnection(Properties var0) {
        String var1 = var0.getProperty("db.url");
        String var2 = var0.getProperty("db.user");
        String var3 = var0.getProperty("db.password");

        try {
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/transport_db", "root","Hexaware@12345");
        } catch (SQLException var5) {
            System.out.println("Database connection failed: " + var5.getMessage());
            return null;
        }
    }
}
