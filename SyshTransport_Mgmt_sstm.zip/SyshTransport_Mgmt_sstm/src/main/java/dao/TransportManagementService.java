package dao;

import entity.Booking;
import entity.Driver;
import entity.Vehicle;
import exception.BookingNotFoundException;
import exception.VehicleNotFoundException;

import java.util.List;

public interface TransportManagementService {
    boolean addVehicle(Vehicle vehicle);
    boolean deleteVehicle(int vehicleId) throws VehicleNotFoundException;
    boolean updateVehicle(Vehicle vehicle) throws VehicleNotFoundException;

    List<Vehicle> getAllVehicles();

    boolean mapDriverToVehicle(Driver driver, int vehicleId);
    boolean isDriverMappedToVehicle(int driverId, int vehicleId);
    boolean bookVehicle(Booking booking);
    Vehicle getVehicleById(int vehicleId) throws VehicleNotFoundException;
    Booking getBookingById(int bookingId) throws BookingNotFoundException;
    boolean cancelTrip(int tripId);
    boolean cancelBooking(int bookingId) throws BookingNotFoundException;
    List<Booking> getBookingsByPassenger(int passengerId);
    List<Booking> getBookingsByTrip(int tripId);
    List<Driver> getAvailableDrivers();
}