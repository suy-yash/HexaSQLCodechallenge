package dao;

import entity.Booking;
import entity.Driver;
import entity.Vehicle;
import exception.BookingNotFoundException;
import exception.VehicleNotFoundException;

import java.util.*;
import java.util.stream.Collectors;

public class TransportManagementServiceImpl implements TransportManagementService {
    private Map<Integer, Vehicle> vehicles = new HashMap<>();
    private Map<Integer, Driver> drivers = new HashMap<>();
    private Map<Integer, Booking> bookings = new HashMap<>();
    private int vehicleIdCounter = 1;
    private int bookingIdCounter = 1;

    public TransportManagementServiceImpl() {
        // Properties not used in in-memory version
    }

    @Override
    public boolean addVehicle(Vehicle vehicle) {
        vehicle.setId(vehicleIdCounter++);
        vehicles.put(vehicle.getId(), vehicle);
        return true;
    }

    @Override
    public boolean deleteVehicle(int vehicleId) throws VehicleNotFoundException {
        if (!vehicles.containsKey(vehicleId)) {
            throw new VehicleNotFoundException("Vehicle not found with ID: " + vehicleId);
        }
        vehicles.remove(vehicleId);
        return true;
    }

    @Override
    public boolean updateVehicle(Vehicle vehicle) throws VehicleNotFoundException {
        if (!vehicles.containsKey(vehicle.getId())) {
            throw new VehicleNotFoundException("Vehicle not found with ID: " + vehicle.getId());
        }
        vehicles.put(vehicle.getId(), vehicle);
        return true;
    }

    @Override
    public List<Vehicle> getAllVehicles() {
        return new ArrayList<>(vehicles.values());
    }

    @Override
    public boolean mapDriverToVehicle(Driver driver, int vehicleId) {
        return true; // Placeholder
    }

    @Override
    public boolean isDriverMappedToVehicle(int driverId, int vehicleId) {
        return true; // Placeholder
    }

    @Override
    public boolean bookVehicle(Booking booking) {
        booking.setId(bookingIdCounter++);
        bookings.put(booking.getId(), booking);
        return true;
    }

    @Override
    public Vehicle getVehicleById(int vehicleId) throws VehicleNotFoundException {
        Vehicle vehicle = vehicles.get(vehicleId);
        if (vehicle == null) {
            throw new VehicleNotFoundException("Vehicle not found with ID: " + vehicleId);
        }
        return vehicle;
    }

    @Override
    public Booking getBookingById(int bookingId) throws BookingNotFoundException {
        Booking booking = bookings.get(bookingId);
        if (booking == null) {
            throw new BookingNotFoundException("Booking not found with ID: " + bookingId);
        }
        return booking;
    }

    @Override
    public boolean cancelTrip(int tripId) {
        return true; // Placeholder
    }

    @Override
    public boolean cancelBooking(int bookingId) throws BookingNotFoundException {
        if (!bookings.containsKey(bookingId)) {
            throw new BookingNotFoundException("Booking not found with ID: " + bookingId);
        }
        bookings.remove(bookingId);
        return true;
    }

    @Override
    public List<Booking> getBookingsByPassenger(int passengerId) {
        return bookings.values().stream()
                .filter(booking -> booking.getPassengerId() == passengerId)
                .collect(Collectors.toList());
    }

    @Override
    public List<Booking> getBookingsByTrip(int tripId) {
        return bookings.values().stream()
                .filter(booking -> booking.getTripId() == tripId)
                .collect(Collectors.toList());
    }

    @Override
    public List<Driver> getAvailableDrivers() {
        return drivers.values().stream()
                .filter(Driver::isAvailable)
                .collect(Collectors.toList());
    }
}