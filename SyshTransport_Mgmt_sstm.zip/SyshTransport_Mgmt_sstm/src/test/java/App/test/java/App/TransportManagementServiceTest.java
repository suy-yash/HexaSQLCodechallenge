package test.java.App;

import static org.junit.jupiter.api.Assertions.*;
import dao.TransportManagementService;
import dao.TransportManagementServiceImpl;
import entity.Vehicle;
import entity.Driver;
import entity.Booking;
import exception.VehicleNotFoundException;
import exception.DriverNotFoundException;
import exception.BookingNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

public class TransportManagementServiceTest {
    private TransportManagementService service;

    public TransportManagementServiceTest() {
    }

    @BeforeEach
    public void setUp() {
        // Instantiate without properties
        this.service = new TransportManagementServiceImpl(); // No arguments
    }

    @Test
    public void testAddVehicle() {
        Vehicle vehicle = new Vehicle("TestModel", 50.0, "Bus", "Available");
        Assertions.assertTrue(this.service.addVehicle(vehicle), "Vehicle should be added successfully");
    }

    @Test
    public void testDeleteNonExistingVehicle() {
        Assertions.assertThrows(VehicleNotFoundException.class, () -> {
            this.service.deleteVehicle(9999);
        });
    }

    @Test
    public void testMapDriverToVehicle() {
        Driver driver = new Driver("John Doe", "D12345");
        Vehicle vehicle = new Vehicle("TestModel", 50.0, "Bus", "Available");
        this.service.addVehicle(vehicle);
        Assertions.assertTrue(this.service.mapDriverToVehicle(driver, vehicle.getId()), "Driver should be mapped to vehicle successfully");
    }

    @Test
    public void testCheckDriverMappedToVehicle() {
        Driver driver = new Driver("John Doe", "D12345");
        Vehicle vehicle = new Vehicle("TestModel", 50.0, "Bus", "Available");
        this.service.addVehicle(vehicle);
        this.service.mapDriverToVehicle(driver, vehicle.getId());
        Assertions.assertTrue(this.service.isDriverMappedToVehicle(driver.getId(), vehicle.getId()), "Driver should be mapped to vehicle");
    }

    @Test
    public void testBookingSuccessfully() {
        Vehicle vehicle = new Vehicle("TestModel", 50.0, "Bus", "Available");
        this.service.addVehicle(vehicle);
        Booking booking = new Booking(vehicle.getId(), "2023-10-01", "10:00 AM");
        Assertions.assertTrue(this.service.bookVehicle(booking), "Booking should be successful");
    }

    @Test
    public void testExceptionThrownWhenVehicleNotFound() {
        Assertions.assertThrows(VehicleNotFoundException.class, () -> {
            this.service.getVehicleById(9999);
        });
    }

    @Test
    public void testExceptionThrownWhenBookingNotFound() {
        Assertions.assertThrows(BookingNotFoundException.class, () -> {
            this.service.getBookingById(9999);
        });
    }
}