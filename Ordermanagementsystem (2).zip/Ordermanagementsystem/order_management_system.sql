create database order_management_system;
use order_management_system;
CREATE TABLE Users (
    userId INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'User ') NOT NULL
);

CREATE TABLE Products (
    productId INT PRIMARY KEY AUTO_INCREMENT,
    productName VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    quantityInStock INT NOT NULL,
    type ENUM('Electronics', 'Clothing') NOT NULL,
    brand VARCHAR(255),
    warrantyPeriod INT,
    size VARCHAR(50),
    color VARCHAR(50)
);

CREATE TABLE Orders (
    orderId INT PRIMARY KEY AUTO_INCREMENT,
    userId INT,
    productId INT,
    FOREIGN KEY (userId) REFERENCES Users(userId),
    FOREIGN KEY (productId) REFERENCES Products(productId)
);

INSERT INTO Users (username, password, role) VALUES
('admin1', 'password1', 'Admin'),
('user1', 'password1', 'User '),
('user2', 'password2', 'User '),
('admin2', 'password2', 'Admin'),
('user3', 'password3', 'User '),
('user4', 'password4', 'User '),
('admin3', 'password3', 'Admin'),
('user5', 'password5', 'User '),
('user6', 'password6', 'User '),
('admin4', 'password4', 'Admin'),
('user7', 'password7', 'User '),
('user8', 'password8', 'User '),
('admin5', 'password5', 'Admin'),
('user9', 'password9', 'User '),
('user10', 'password10', 'User ');
INSERT INTO Products (productName, description, price, quantityInStock, type, brand, warrantyPeriod, size, color) VALUES
('Smartphone', 'Latest model smartphone with high specs', 699.99, 50, 'Electronics', 'BrandA', 24, NULL, NULL),
('Laptop', 'Lightweight laptop for everyday use', 999.99, 30, 'Electronics', 'BrandB', 12, NULL, NULL),
('T-Shirt', 'Cotton t-shirt available in various sizes', 19.99, 100, 'Clothing', NULL, NULL, 'M', 'Blue'),
('Jeans', 'Denim jeans with a comfortable fit', 49.99, 75, 'Clothing', NULL, NULL, 'L', 'Black'),
('Headphones', 'Noise-cancelling over-ear headphones', 199.99, 40, 'Electronics', 'BrandC', 18, NULL, NULL),
('Smartwatch', 'Fitness tracking smartwatch', 249.99, 60, 'Electronics', 'BrandD', 24, NULL, NULL),
('Jacket', 'Warm winter jacket', 89.99, 20, 'Clothing', NULL, NULL, 'L', 'Red'),
('Sneakers', 'Comfortable running sneakers', 79.99, 50, 'Clothing', NULL, NULL, '10', 'White'),
('Tablet', 'Portable tablet with high resolution', 399.99, 25, 'Electronics', 'BrandE', 12, NULL, NULL),
('Charger', 'Fast charging wall adapter', 29.99, 150, 'Electronics', 'BrandF', 6, NULL, NULL),
('Dress', 'Elegant evening dress', 129.99, 30, 'Clothing', NULL, NULL, 'S', 'Black'),
('Shorts', 'Casual summer shorts', 34.99, 80, 'Clothing', NULL, NULL, 'M', 'Green'),
('Camera', 'Digital camera with high resolution', 499.99, 15, 'Electronics', 'BrandG', 24, NULL, NULL),
('Backpack', 'Durable backpack for travel', 59.99, 40, 'Clothing', NULL, NULL, NULL, 'Gray'),
('Sunglasses', 'Stylish sunglasses for summer', 49.99, 100, 'Clothing', NULL, NULL, NULL, 'Black');
INSERT INTO Orders (userId, productId) VALUES
(1, 1),  -- admin1 orders Smartphone
(2, 2),  -- user1 orders Laptop
(3, 3),  -- user2 orders T-Shirt
(4, 4),  -- admin2 orders Jeans
(5, 5),  -- user3 orders Headphones
(6, 6),  -- user4 orders Smartwatch
(7, 7),  -- admin3 orders Jacket
(8, 8),  -- user5 orders Sneakers
(9, 9),  -- user6 orders Tablet
(10, 10), -- admin4 orders Charger
(1, 11), -- admin1 orders Dress
(2, 12), -- user1 orders Shorts
(3, 13), -- user2 orders Camera
(4, 14), -- admin2 orders Backpack
(5, 15); -- user3 orders Sunglasses
