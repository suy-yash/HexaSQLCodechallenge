package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Properties {
    // Database URL, username, and password
    private static final String DB_URL = "jdbc:mysql://localhost:3306/ticketbookingsystem";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "Hexaware@12345";

    public static void main(String[] args) {
        Connection connection = null;

        try {
            // Establishing the connection
            connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
            System.out.println("Connection to the database established successfully!");

            // You can perform database operations here

        } catch (SQLException e) {
            System.out.println("Connection to the database failed!");
            e.printStackTrace();
        } finally {
            // Closing the connection
            if (connection != null) {
                try {
                    connection.close();
                    System.out.println("Database connection closed.");
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}