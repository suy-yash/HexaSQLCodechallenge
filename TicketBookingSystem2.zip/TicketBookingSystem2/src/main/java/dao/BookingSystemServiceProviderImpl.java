package dao;

import entity.model.Booking;
import entity.model.Customer;
import entity.model.Event;

import java.util.ArrayList;
import java.util.List;

public class BookingSystemServiceProviderImpl implements IBookingSystemServiceProvider {
    private List<Booking> bookings = new ArrayList<>();
    private IEventServiceProvider eventServiceProvider;

    public BookingSystemServiceProviderImpl(IEventServiceProvider eventServiceProvider) {
        this.eventServiceProvider = eventServiceProvider;
    }

    @Override
    public double calculateBookingCost(int numTickets, String eventName) {
        int availableTickets = eventServiceProvider.getAvailableNoOfTickets(eventName);
        if (availableTickets >= numTickets) {
         //List<Event> e=  eventServiceProvider.getEventDetails();
         //e.stream().filter(event -> event.getEventName().equals(eventName))
           //      .findFirst().orElseThrow(() -> new RuntimeException("Event not found")).getTicketPrice()
            double totalTicketPrice = numTickets *eventServiceProvider.getEventDetails().stream().filter(event -> event.getEventName().equals(eventName)).findFirst().orElseThrow(() -> new RuntimeException("Event not found")).getTicketPrice();
            return totalTicketPrice;
        }
        return 0; // Not enough tickets available
    }

    @Override
    public Booking bookTickets(String eventName, int numTickets, Customer customer) {
        Event event = eventServiceProvider.getEventDetails().stream()
                .filter(e -> e.getEventName().equals(eventName))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Event not found"));

        event.bookTickets(numTickets);
        Booking booking = new Booking(customer, event, numTickets);
        bookings.add(booking);
        return booking;
    }

    @Override
    public void cancelBooking(int bookingId) {
        bookings.removeIf(booking -> booking.getBookingId() == bookingId);
    }
}