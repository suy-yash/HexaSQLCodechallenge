package dao;

import entity.model.Booking;
import entity.model.Customer;

public interface IBookingSystemServiceProvider {
    double calculateBookingCost(int numTickets, String eventName);
    Booking bookTickets(String eventName, int numTickets, Customer customer);
    void cancelBooking(int bookingId);
}