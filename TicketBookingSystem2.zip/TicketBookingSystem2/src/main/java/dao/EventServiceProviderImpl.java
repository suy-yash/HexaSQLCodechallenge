package dao;

import entity.model.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EventServiceProviderImpl implements IEventServiceProvider {
    private List<Event> events = new ArrayList<>();

    @Override
    public Event createEvent(String eventName, Date date, String time, int totalSeats, double ticketPrice, String eventType, Venue venue) {
        Event event = null;
        switch (eventType) {
            case "Movie":
                event = new Movie(eventName, date, time, venue, totalSeats, ticketPrice, "Genre", "Actor", "Actress");
                break;
            case "Concert":
                event = new Concert(eventName, date, time, venue, totalSeats, ticketPrice, "Artist", "Type");
                break;
            case "Sport":
                event = new Sport(eventName, date, time, venue, totalSeats, ticketPrice, "SportName", "Team1 vs Team2");
                break;
        }
        if (event != null) {
            events.add(event);
        }
        return event;
    }

    @Override
    public List<Event> getEventDetails() {
        return events;
    }

    @Override
    public int getAvailableNoOfTickets(String eventName) {
        for (Event event : events) {
            if (event.getEventName().equals(eventName)) {
                return event.getAvailableSeats();
            }
        }
        return 0; // Event not found
    }
}