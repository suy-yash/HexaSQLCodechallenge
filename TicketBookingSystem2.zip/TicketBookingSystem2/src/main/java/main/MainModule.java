package main;

import entity.model.*;
import dao.*;
import util.DBPropertyUtil;

import java.util.Date;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        IEventServiceProvider eventService = new EventServiceProviderImpl();
        IBookingSystemServiceProvider bookingService = new BookingSystemServiceProviderImpl(eventService);

        // Sample Venue
        Venue venue = new Venue("Grand Theatre", "123 Main St");

        // Create Events
        eventService.createEvent("Avengers: Endgame", new Date(), "18:00", 100, 10.0, "Movie", venue);
        eventService.createEvent("Rock Concert", new Date(), "20:00", 200, 15.0, "Concert", venue);
        eventService.createEvent("Football Match", new Date(), "16:00", 150, 12.0, "Sport", venue);

        // Menu-driven interface
        while (true) {
            System.out.println("1. View Events");
            System.out.println("2. Book Tickets");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    for (Event event : eventService.getEventDetails()) {
                        event.displayEventDetails();
                    }
                    break;
                case 2:
                    System.out.print("Enter event name: ");
                    String eventName = scanner.next();
                    System.out.print("Enter number of tickets: ");
                    int numTickets = scanner.nextInt();
                    System.out.print("Enter customer name: ");
                    String customerName = scanner.next();
                    Customer customer = new Customer(customerName, "email@example.com", "1234567890");
                    try {
                        Booking booking = bookingService.bookTickets(eventName, numTickets, customer);
                        booking.displayBookingDetails();
                    } catch (RuntimeException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}