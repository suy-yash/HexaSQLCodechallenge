package entity.model;

import java.util.Date;

public abstract class Event {
    protected String eventName;
    protected Date eventDate;
    protected String eventTime;
    protected Venue venue;
    protected int totalSeats;
    protected int availableSeats;
    protected double ticketPrice;
    protected String eventType;

    public Event() {}

    public Event(String eventName, Date eventDate, String eventTime, Venue venue, int totalSeats, double ticketPrice, String eventType) {
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.venue = venue;
        this.totalSeats = totalSeats;
        this.availableSeats = totalSeats; // Initially, available seats are equal to total seats
        this.ticketPrice = ticketPrice;
        this.eventType = eventType;
    }

    public abstract void displayEventDetails();

    public void bookTickets(int numTickets) {
        if (numTickets <= availableSeats) {
            availableSeats -= numTickets;
            System.out.println(numTickets + " tickets booked for " + eventName);
        } else {
            System.out.println("Not enough available seats.");
        }
    }

    public void cancelBooking(int numTickets) {
        availableSeats += numTickets;
        System.out.println(numTickets + " tickets canceled for " + eventName);
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public double calculateTotalRevenue(int ticketsSold) {
        return ticketsSold * ticketPrice;
    }

    public String getEventName() {
        return eventName;
    }

    public double getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(double ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }
}