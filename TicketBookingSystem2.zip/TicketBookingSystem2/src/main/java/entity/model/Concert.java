package entity.model;

import java.util.Date;

public class Concert extends Event {
    private String artist;
    private String type;

    public Concert(String eventName, Date eventDate, String eventTime, Venue venue, int totalSeats, double ticketPrice, String artist, String type) {
        super(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, "Concert");
        this.artist = artist;
        this.type = type;
    }

    @Override
    public void displayEventDetails() {
        System.out.println("Concert Name: " + eventName);
        System.out.println("Artist: " + artist);
        System.out.println("Type: " + type);
        System.out.println("Date: " + eventDate);
        System.out.println("Time: " + eventTime);
        System.out.println("Venue: " + venue.getVenueName());
        System.out.println("Available Seats: " + availableSeats);
    }
}