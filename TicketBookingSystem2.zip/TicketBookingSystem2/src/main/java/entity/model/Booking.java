package entity.model;

import java.util.Date;

public class Booking {
    private static int bookingIdCounter = 1; // Static counter for booking IDs
    private int bookingId;
    private Customer customer;
    private Event event;
    private int numTickets;
    private double totalCost;
    private Date bookingDate;

    public Booking(Customer customer, Event event, int numTickets) {
        this.bookingId = bookingIdCounter++;
        this.customer = customer;
        this.event = event;
        this.numTickets = numTickets;
        this.totalCost = event.getTicketPrice() * numTickets;
        this.bookingDate = new Date();
    }

    public int getBookingId() {
        return bookingId;
    }

    public void displayBookingDetails() {
        System.out.println("Booking ID: " + bookingId);
        System.out.println("Customer: " + customer.getCustomerName());
        System.out.println("Event: " + event.getEventName());
        System.out.println("Number of Tickets: " + numTickets);
        System.out.println("Total Cost: " + totalCost);
        System.out.println("Booking Date: " + bookingDate);
    }
}