package entity.model;

import java.util.Date;

public class Movie extends Event {
    private String genre;
    private String actorName;
    private String actressName;

    public Movie(String eventName, Date eventDate, String eventTime, Venue venue, int totalSeats, double ticketPrice, String genre, String actorName, String actressName) {
        super(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, "Movie");
        this.genre = genre;
        this.actorName = actorName;
        this.actressName = actressName;
    }

    @Override
    public void displayEventDetails() {
        System.out.println("Movie Name: " + eventName);
        System.out.println("Genre: " + genre);
        System.out.println("Actor: " + actorName);
        System.out.println("Actress: " + actressName);
        System.out.println("Date: " + eventDate);
        System.out.println("Time: " + eventTime);
        System.out.println("Venue: " + venue.getVenueName());
        System.out.println("Available Seats: " + availableSeats);
    }
}