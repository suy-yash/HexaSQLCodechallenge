package Main;

import dao.OrderProcessor;
import entity.Clothing;
import entity.Electronics;
import entity.Product;
import entity.User;

import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        OrderProcessor orderProcessor = new OrderProcessor();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Order Management System Menu:");
            System.out.println("1. Create User");
            System.out.println("2. Create Product");
            System.out.println("3. Cancel Order");
            System.out.println("4. Get All Products");
            System.out.println("5. Get Orders by User");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();
                    System.out.print("Enter role (Admin/User): ");
                    String role = scanner.nextLine();
                    User newUser  = new User(0, username, password, role);
                    orderProcessor.createUser (newUser );
                    System.out.println("User  created successfully.");
                    break;

                case 2:
                    System.out.print("Enter product name: ");
                    String productName = scanner.nextLine();
                    System.out.print("Enter description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter quantity in stock: ");
                    int quantityInStock = scanner.nextInt();
                    System.out.print("Enter type (Electronics/Clothing): ");
                    String type = scanner.next();
                    Product newProduct;
                    if (type.equalsIgnoreCase("Electronics")) {
                        System.out.print("Enter brand: ");
                        String brand = scanner.next();
                        System.out.print("Enter warranty period: ");
                        int warrantyPeriod = scanner.nextInt();
                        newProduct = new Electronics(0, productName, description, price, quantityInStock, brand, warrantyPeriod);
                    } else {
                        System.out.print("Enter size: ");
                        String size = scanner.next();
                        System.out.print("Enter color: ");
                        String color = scanner.next();
                        newProduct = new Clothing(0, productName, description, price, quantityInStock, size, color);
                    }
                    orderProcessor.createProduct(new User(0, "admin", "admin", "Admin"), newProduct); // Assuming admin user
                    System.out.println("Product created successfully.");
                    break;

                case 3:
                    System.out.print("Enter user ID: ");
                    int userId = scanner.nextInt();
                    System.out.print("Enter order ID: ");
                    int orderId = scanner.nextInt();
                    orderProcessor.cancelOrder(userId, orderId);
                    System.out.println("Order cancelled successfully.");
                    break;

                case 4:
                    List<Product> products = orderProcessor.getAllProducts();
                    System.out.println("Available Products:");
                    for (Product product : products) {
                        System.out.println(product.getProductName() + " - " + product.getPrice());
                    }
                    break;

                case 5:
                    System.out.print("Enter user ID: ");
                    int userIdForOrders = scanner.nextInt();
                    User user = new User(userIdForOrders, "", "", ""); // Dummy user for fetching orders
                    List<Product> userOrders = orderProcessor.getOrderByUser (user);
                    System.out.println("Orders for User ID " + userIdForOrders + ":");
                    for (Product order : userOrders) {
                        System.out.println(order.getProductName());
                    }
                    break;

                case 6:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);

        scanner.close();
    }
}
