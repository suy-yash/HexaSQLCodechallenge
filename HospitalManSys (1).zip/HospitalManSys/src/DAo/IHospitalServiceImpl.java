package DAo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Entity.Appointment;
import Exception.DepartmentNotFoundException;
import Excption.PatientNotFoundException;
import util.DBConUtil;

public class IHospitalServiceImpl implements IHospitalService {

	@Override
	public Appointment getAppoin(int appointmentId) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM Appointment WHERE appointmentId = ?";

		Appointment appoin = null;

        try(Connection conn = DBConUtil.getConnection();

            PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1,appointmentId );

            ResultSet rs = stmt.executeQuery();

            while(rs.next())

			{

			int AppointmentID = rs.getInt("appointmentId");
			String appointmentDate = rs.getString("appointmentDate");
			int DoctorID = rs.getInt("doctorId");
			int PatientID = rs.getInt("patientId");
			
			String description = rs.getString("description");

            System.out.println("PatientID "+ PatientID + ",DoctorID " + DoctorID +"AppointmentID: " + AppointmentID);
            System.out.println("Description:  "+description);
            System.out.println("appointmentDate"+appointmentDate);

			}
            return appoin;

        } catch (SQLException e) {

            System.out.println("Error Occurred 2: " + e.getMessage());
            
            
        }

		
		return null;

	}

	
	@Override
	public Appointment getAppoinForPatient(int patientId) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM Appointment WHERE patientId = ?";

		Appointment obj = null;

        try(Connection conn = DBConUtil.getConnection();

            PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1,patientId );

            ResultSet rs = stmt.executeQuery();
            int patientId1=0;
            if(rs!=null)
            {

            while(rs.next())

			{

			int AppointmentID = rs.getInt("appointmentId");
			String appointmentDate = rs.getString("appointmentDate");
			int DoctorID = rs.getInt("doctorId");
			int PatientID = rs.getInt("patientId");
			
			String description = rs.getString("description");

            System.out.println("AppointmentID: " + AppointmentID + ",DoctorID " + DoctorID + ",PatientID "+ PatientID);
            System.out.println("Description:  "+description);
            System.out.println("appointmentDate"+appointmentDate);

			}
            }
            if(patientId1 != patientId) {
                throw new PatientNotFoundException("Department with depid: " + patientId + " not found");
            }

        } catch (SQLException e1) {
            System.out.println("Error Occurred 2: " + e1.getMessage());
        }
         catch (PatientNotFoundException e) {
            System.out.println("Error Occurred : " + e.getMessage());
 
        }

        

		
		return null;
		
	}

	@Override
	public Appointment getAppoinForDoctor(int doctorId) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM Appointment WHERE doctorId = ?";

		Appointment obj = null;

        try(Connection conn = DBConUtil.getConnection();

            PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1,doctorId );

            ResultSet rs = stmt.executeQuery();

            while(rs.next())

			{

			int AppointmentID = rs.getInt("appointmentId");
			String appointmentDate = rs.getString("appointmentDate");
			int DoctorID = rs.getInt("doctorId");
			int PatientID = rs.getInt("patientId");
			
			String description = rs.getString("description");

            System.out.println("AppointmentID: " + AppointmentID + ",DoctorID " + DoctorID + ",PatientID "+ PatientID);
            System.out.println("Description:  "+description);
            System.out.println("appointmentDate"+appointmentDate);

			}
            return obj;

        } catch (SQLException e) {

            System.out.println("Error Occurred 2: " + e.getMessage());
            
            
        }

		
		return null;
		
	}


	public void getDept(int id) {
		// TODO Auto-generated method stub
		
	}

}
