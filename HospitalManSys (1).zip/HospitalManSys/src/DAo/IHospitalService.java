package DAo;

import java.util.List;

import Entity.Appointment;

public interface IHospitalService {
	public Appointment getAppoin(int appointmentId);//get details by their id //
	public Appointment getAppoinForPatient(int patientId);//get details by their id 
	public Appointment getAppoinForDoctor(int doctorId);//get details by their id 

}
