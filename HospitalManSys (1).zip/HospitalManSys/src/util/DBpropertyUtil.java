package util;


import java.io.InputStream;
import java.sql.*;
import java.util.Properties;
//jdbc connectivity

public class DBpropertyUtil {
	public static Properties getPropeties() {
		Properties properties = new Properties();
		try(InputStream input = DBpropertyUtil.class.getClassLoader().
		getResourceAsStream("db.properties"))
				
		{
			properties.load(input);
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return properties;
	}

}