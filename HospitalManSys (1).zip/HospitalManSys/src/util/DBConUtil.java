package util;


import java.sql.*;
import java.util.Properties;
//jdbc connectivity

public class DBConUtil {
	private static Connection connection;
	public static Connection getConnection()
	{
		if(connection == null)
		{
			try
			{
				Properties properties=DBpropertyUtil.getPropeties();
				String url=properties.getProperty("db.url");
				String username=properties.getProperty("db.username");
				String password=properties.getProperty("db.password");
				connection =DriverManager.getConnection(url,username,password);
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				
			}
		}
		return connection;
	}

}