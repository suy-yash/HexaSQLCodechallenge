package Excption;

public class PatientNotFoundException extends Exception {
	public PatientNotFoundException()
	{
		super("Patient Not Found");
	}
	public PatientNotFoundException(String message) //--exception
	{
		super(message);
	}
}

