package Main;

import java.util.Scanner;

import DAo.IHospitalServiceImpl;

public class HospitalMan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the choice that what you want to do:");
		System.out.println("1. fecth data by Appointment");
		System.out.println("2. fecth data by Patient");
		System.out.println("3. fecth data by Doctor");
		System.out.println("4. ");
		System.out.println("5");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		
		switch(choice) {
		case 1:
			fecthgetAppoin();
			
			break;
			
		case 2:
			fecthgetAppoinForPatient();
			break;
			
		case 3:
			fecthgetAppoinForDoctor();
			break;
			
		case 4:
			
			break;
			
		case 5:
			break;

		}

	}

	private static void fecthgetAppoinForDoctor() {
		// TODO Auto-generated method stub
		IHospitalServiceImpl obj=new IHospitalServiceImpl();
		 Scanner sc = new Scanner(System.in);
	      System.out.println("Enter Doctor ID to fetch: ");
	      int id = sc.nextInt();
		   obj.getAppoinForDoctor(id);
		
	}

	private static void fecthgetAppoinForPatient() {
		// TODO Auto-generated method stub
		IHospitalServiceImpl obj=new IHospitalServiceImpl();
		 Scanner sc = new Scanner(System.in);
	      System.out.println("Enter Patient ID to fetch: ");
	      int id = sc.nextInt();
		   obj.getAppoinForPatient(id);
		
	}

	private static void fecthgetAppoin() {
		// TODO Auto-generated method stub
		IHospitalServiceImpl obj=new IHospitalServiceImpl();
		 Scanner sc = new Scanner(System.in);
	      System.out.println("Enter oppinitment ID to fetch: ");
	      int id = sc.nextInt();
		   obj.getAppoin(id);
		
	}

}
